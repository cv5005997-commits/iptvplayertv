# MPVLib se llama desde código nativo (JNI): no se puede renombrar ni quitar.
-keep class is.xyz.mpv.** { *; }
