package com.iptvplayertv

import android.content.Context

/** Una opción configurable: 6 valores posibles y uno por defecto. */
class Opt(
    val key: String,
    val title: String,
    val unit: String,
    val values: IntArray,
    val def: Int,
    val labels: List<String>? = null, // textos a mostrar, si no se quiere "valor + unidad"
)

object Cfg {
    // Video: 0 = hardware, 1 = hardware con copia, 2 = software
    val hw = Opt(
        "hw", "Decodificación de video", "", intArrayOf(0, 1, 2), 0,
        listOf("Hardware (recomendado)", "Hardware con copia", "Software")
    )

    // Buffer hacia adelante
    val fwd = Opt("buf_fwd", "Tamaño del buffer", "MiB", intArrayOf(16, 32, 48, 64, 96, 128), 64)
    val ahead = Opt("ahead", "Lectura adelantada", "seg", intArrayOf(10, 20, 30, 40, 60, 90), 40)
    val wait = Opt("wait", "Pausa para recargar", "seg", intArrayOf(1, 2, 3, 5, 8, 10), 3)

    // Buffer hacia atrás
    val back = Opt("buf_back", "Tamaño del buffer", "MiB", intArrayOf(2, 4, 8, 16, 32, 64), 8)

    private const val FILE = "iptvplayertv"

    fun get(ctx: Context, o: Opt): Int =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt(o.key, o.def)

    fun set(ctx: Context, o: Opt, value: Int) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt(o.key, value).apply()
    }

    fun getUrl(ctx: Context): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("m3u_url", "") ?: ""

    fun setUrl(ctx: Context, url: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("m3u_url", url).apply()
    }
}
