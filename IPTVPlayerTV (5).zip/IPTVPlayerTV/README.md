# IPTVPlayerTV (v0.1)

App mínima: pegas la URL de una lista M3U, se cargan los canales y se reproducen con mpv (libmpv).
Sin AppCompat ni librerías extra para que el APK sea lo más pequeño posible.

## Compilar
1. Abre la carpeta en Android Studio (necesita Android SDK 34) y espera la sincronización de Gradle.
2. Confirma en https://central.sonatype.com/artifact/dev.jdtech.mpv/libmpv la última versión y ajústala en `app/build.gradle.kts`.
3. `Build > Build APK(s)` (o `./gradlew assembleRelease`).

## Reducir tamaño
- `abiFilters` en `app/build.gradle.kts`: deja solo `arm64-v8a` si tus equipos lo permiten (Android TV viejos con poca RAM suelen ser `armeabi-v7a`).
- R8 y shrinkResources ya están activados en release.
