package com.iptvplayertv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import is.xyz.mpv.MPVLib
import java.net.HttpURLConnection
import java.net.URL

/** Un canal de la lista M3U. */
private data class Channel(val name: String, val url: String) {
    override fun toString() = name
}

class MainActivity : Activity(), SurfaceHolder.Callback {

    private lateinit var surface: SurfaceView
    private lateinit var urlInput: EditText
    private lateinit var list: ListView
    private lateinit var status: TextView

    private val channels = mutableListOf<Channel>()
    private var pendingUrl: String? = null
    private var surfaceReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        initMpv()
    }

    // ---------- UI mínima, solo vistas del sistema (sin AppCompat) ----------

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B1220"))
        }

        surface = SurfaceView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 2f)
            holder.addCallback(this@MainActivity)
        }
        root.addView(surface)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        urlInput = EditText(this).apply {
            hint = "URL de la lista M3U"
            setText(Cfg.getUrl(this@MainActivity))
            setSingleLine()
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val load = Button(this).apply {
            text = "Cargar"
            setOnClickListener { loadPlaylist(urlInput.text.toString().trim()) }
        }
        val settings = Button(this).apply {
            text = "Ajustes"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        row.addView(urlInput)
        row.addView(load)
        row.addView(settings)
        root.addView(row)

        status = TextView(this).apply { setTextColor(Color.LTGRAY); setPadding(16, 4, 16, 4) }
        root.addView(status)

        list = ListView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 3f)
            setOnItemClickListener { _, _, pos, _ -> play(channels[pos]) }
        }
        root.addView(list)

        setContentView(root)
    }

    // ---------- mpv (solo funciones que ya se usaban en la v0.1) ----------

    /** Aplica los valores de buffer guardados en Ajustes. */
    private fun applyBuffers(runtime: Boolean) {
        val opts = listOf(
            "demuxer-max-bytes" to "${Cfg.get(this, Cfg.fwd)}MiB",
            "demuxer-max-back-bytes" to "${Cfg.get(this, Cfg.back)}MiB",
            "demuxer-readahead-secs" to "${Cfg.get(this, Cfg.ahead)}",
            "cache" to "yes",
            "cache-pause" to "yes",
            "cache-pause-wait" to "${Cfg.get(this, Cfg.wait)}",
        )
        for ((k, v) in opts) {
            if (runtime) MPVLib.setPropertyString(k, v) else MPVLib.setOptionString(k, v)
        }
    }

    private fun initMpv() {
        MPVLib.create(applicationContext)
        MPVLib.setOptionString("config", "yes")
        MPVLib.setOptionString("config-dir", filesDir.path)
        MPVLib.setOptionString("gpu-shader-cache-dir", cacheDir.path)
        MPVLib.setOptionString("icc-cache-dir", cacheDir.path)

        MPVLib.setOptionString("vo", "gpu")
        MPVLib.setOptionString("gpu-context", "android")
        MPVLib.setOptionString("opengl-es", "yes")
        MPVLib.setOptionString("hwdec", "mediacodec,mediacodec-copy")
        MPVLib.setOptionString("ao", "audiotrack,opensles")

        // Red: reconexión automática y tiempo de espera
        MPVLib.setOptionString("network-timeout", "15")
        MPVLib.setOptionString(
            "stream-lavf-o",
            "reconnect=1,reconnect_streamed=1,reconnect_delay_max=5"
        )

        applyBuffers(runtime = false)

        MPVLib.init()
        MPVLib.setOptionString("force-window", "no")
        MPVLib.setOptionString("idle", "once")
    }

    private fun play(ch: Channel) {
        pendingUrl = ch.url
        status.text = ch.name
        applyBuffers(runtime = true) // toma los cambios hechos en Ajustes
        if (surfaceReady) MPVLib.command(arrayOf("loadfile", ch.url))
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        MPVLib.attachSurface(holder.surface)
        MPVLib.setOptionString("force-window", "yes")
        surfaceReady = true
        pendingUrl?.let { MPVLib.command(arrayOf("loadfile", it)) }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        MPVLib.setPropertyString("android-surface-size", "${w}x$h")
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
        MPVLib.setPropertyString("vo", "null")
        MPVLib.setOptionString("force-window", "no")
        MPVLib.detachSurface()
    }

    override fun onDestroy() {
        surface.holder.removeCallback(this)
        MPVLib.destroy()
        super.onDestroy()
    }

    // ---------- Lista M3U ----------

    private fun loadPlaylist(url: String) {
        if (url.isEmpty()) {
            Toast.makeText(this, "Pega la URL de la lista", Toast.LENGTH_SHORT).show()
            return
        }
        Cfg.setUrl(this, url)
        status.text = "Descargando lista..."
        Thread {
            try {
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 30000
                    instanceFollowRedirects = true
                }
                val parsed = conn.inputStream.bufferedReader().useLines { parseM3u(it) }
                runOnUiThread {
                    channels.clear()
                    channels.addAll(parsed)
                    list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, channels)
                    status.text = "${channels.size} canales"
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Error: ${e.message}" }
            }
        }.start()
    }

    private fun parseM3u(lines: Sequence<String>): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        for (raw in lines) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> name = line.substringAfterLast(',', "").trim()
                line.isNotEmpty() && !line.startsWith("#") -> {
                    out.add(Channel(name?.ifEmpty { null } ?: line, line))
                    name = null
                }
            }
        }
        return out
    }
}
