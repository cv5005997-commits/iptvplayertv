package com.iptvplayertv

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView

class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 24, 32, 24)
        }

        section(box, "Buffer hacia adelante")
        option(box, Cfg.fwd)
        option(box, Cfg.ahead)
        option(box, Cfg.wait)

        section(box, "Buffer hacia atrás")
        option(box, Cfg.back)

        val note = TextView(this).apply {
            text = "Los cambios se aplican al abrir el siguiente canal."
            setTextColor(Color.GRAY)
            setPadding(0, 32, 0, 0)
        }
        box.addView(note)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B1220"))
            addView(box)
        })
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title
            textSize = 18f
            setTextColor(Color.parseColor("#7DB7FF"))
            setPadding(0, 32, 0, 8)
        })
    }

    private fun option(parent: LinearLayout, o: Opt) {
        parent.addView(TextView(this).apply {
            text = o.title
            setTextColor(Color.WHITE)
        })
        val labels = o.values.map { "$it ${o.unit}" }
        val spinner = Spinner(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, labels)
            val current = Cfg.get(this@SettingsActivity, o)
            setSelection(o.values.indexOf(current).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    Cfg.set(this@SettingsActivity, o, o.values[pos])
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        parent.addView(spinner)
    }
}
