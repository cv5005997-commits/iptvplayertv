plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.iptvplayertv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.iptvplayertv"
        minSdk = 21
        targetSdk = 34
        versionCode = 2
        versionName = "0.2"
        // Solo las ABIs que necesitas: cada una suma varios MB por las librerías de mpv.
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug") // solo para pruebas
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs { useLegacyPackaging = true } // libs nativas comprimidas dentro del APK
    }
}

dependencies {
    // libmpv para Android. Verifica la última versión en Maven Central antes de compilar.
    implementation("dev.jdtech.mpv:libmpv:0.5.1")
}
