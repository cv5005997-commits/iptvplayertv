package com.iptvplayertv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import is.xyz.mpv.MPVLib
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Un canal de la lista M3U. */
private data class Channel(val name: String, val url: String) {
    override fun toString() = name
}

class MainActivity : Activity(), SurfaceHolder.Callback {

    private lateinit var surface: SurfaceView
    private lateinit var urlInput: EditText
    private lateinit var list: ListView
    private lateinit var status: TextView

    private val channels = mutableListOf<Channel>()
    @Volatile private var pendingUrl: String? = null
    @Volatile private var surfaceReady = false

    // Las órdenes pesadas a mpv van en otro hilo: si el canal se queda esperando
    // red, mpv tarda en responder y la pantalla no debe congelarse.
    // Un grupo de hilos (no uno solo) para que una orden trabada no bloquee a las demás.
    private val mpvExec = Executors.newCachedThreadPool()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        initMpv()
    }

    // ---------- UI mínima, solo vistas del sistema (sin AppCompat) ----------

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B1220"))
        }

        surface = SurfaceView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 2f)
            holder.addCallback(this@MainActivity)
        }
        root.addView(surface)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        urlInput = EditText(this).apply {
            hint = "URL de la lista M3U"
            setText(Cfg.getUrl(this@MainActivity))
            setSingleLine()
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val load = Button(this).apply {
            text = "Cargar"
            setOnClickListener { loadPlaylist(urlInput.text.toString().trim()) }
        }
        val settings = Button(this).apply {
            text = "Ajustes"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        row.addView(urlInput)
        row.addView(load)
        row.addView(settings)
        root.addView(row)

        status = TextView(this).apply { setTextColor(Color.LTGRAY); setPadding(16, 4, 16, 4) }
        root.addView(status)

        list = ListView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 3f)
            setOnItemClickListener { _, _, pos, _ -> play(channels[pos]) }
        }
        root.addView(list)

        setContentView(root)
    }

    // ---------- mpv (solo funciones que ya se usaban en la v0.1) ----------

    /** Aplica los valores de buffer guardados en Ajustes. */
    private fun applyBuffers(runtime: Boolean) {
        val hwdec = when (Cfg.get(this, Cfg.hw)) {
            1 -> "mediacodec-copy"
            2 -> "no"
            else -> "mediacodec,mediacodec-copy"
        }
        val opts = listOf(
            "hwdec" to hwdec,
            "demuxer-max-bytes" to "${Cfg.get(this, Cfg.fwd)}MiB",
            "demuxer-max-back-bytes" to "${Cfg.get(this, Cfg.back)}MiB",
            "demuxer-readahead-secs" to "${Cfg.get(this, Cfg.ahead)}",
            "cache" to "yes",
            "cache-pause" to "yes",
            "cache-pause-wait" to "${Cfg.get(this, Cfg.wait)}",
        )
        for ((k, v) in opts) {
            // El tipo de decodificación se fija solo al abrir la app, nunca con el video andando.
            if (runtime && k == "hwdec") continue
            if (runtime) MPVLib.setPropertyString(k, v) else MPVLib.setOptionString(k, v)
        }
    }

    private fun initMpv() {
        MPVLib.create(applicationContext)
        MPVLib.setOptionString("config", "yes")
        MPVLib.setOptionString("config-dir", filesDir.path)
        MPVLib.setOptionString("gpu-shader-cache-dir", cacheDir.path)
        MPVLib.setOptionString("icc-cache-dir", cacheDir.path)

        MPVLib.setOptionString("vo", "gpu")
        MPVLib.setOptionString("gpu-context", "android")
        MPVLib.setOptionString("opengl-es", "yes")
        MPVLib.setOptionString("ao", "audiotrack,opensles")

        // Red: solo tiempo de espera (sin reconexión de FFmpeg, que puede colgar streams en vivo)
        MPVLib.setOptionString("network-timeout", "15")

        applyBuffers(runtime = false)

        MPVLib.init()
        MPVLib.setOptionString("force-window", "no")
        MPVLib.setOptionString("idle", "once")
    }

    private fun play(ch: Channel) {
        pendingUrl = ch.url
        status.text = ch.name
        mpvExec.execute {
            applyBuffers(runtime = true) // toma los cambios hechos en Ajustes
            if (surfaceReady) MPVLib.command(arrayOf("loadfile", ch.url))
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        MPVLib.attachSurface(holder.surface)
        MPVLib.setOptionString("force-window", "yes")
        surfaceReady = true
        pendingUrl?.let { url -> mpvExec.execute { MPVLib.command(arrayOf("loadfile", url)) } }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        MPVLib.setPropertyString("android-surface-size", "${w}x$h")
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
        MPVLib.setPropertyString("vo", "null")
        MPVLib.setOptionString("force-window", "no")
        MPVLib.detachSurface()
    }

    override fun onDestroy() {
        surface.holder.removeCallback(this)
        mpvExec.shutdownNow()
        MPVLib.destroy()
        super.onDestroy()
    }

    // ---------- Lista M3U ----------

    private fun loadPlaylist(url: String) {
        if (url.isEmpty()) {
            Toast.makeText(this, "Pega la URL de la lista", Toast.LENGTH_SHORT).show()
            return
        }
        Cfg.setUrl(this, url)
        status.text = "Descargando lista..."
        Thread {
            try {
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 30000
                    instanceFollowRedirects = true
                }
                val parsed = conn.inputStream.bufferedReader().useLines { parseM3u(it) }
                runOnUiThread {
                    channels.clear()
                    channels.addAll(parsed)
                    list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, channels)
                    status.text = "${channels.size} canales"
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Error: ${e.message}" }
            }
        }.start()
    }

    private fun parseM3u(lines: Sequence<String>): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        for (raw in lines) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> name = line.substringAfterLast(',', "").trim()
                line.isNotEmpty() && !line.startsWith("#") -> {
                    out.add(Channel(name?.ifEmpty { null } ?: line, line))
                    name = null
                }
            }
        }
        return out
    }
}
